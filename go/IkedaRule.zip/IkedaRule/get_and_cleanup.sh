wget -np -r -k http://qitailang.small.jp/go/rule/ikeda/index.html
wget http://qitailang.small.jp/go/rule/ikeda/images/white.gif
wget -np -r -k https://harryfearnley.com/go/ikeda/
mv white.gif ./harryfearnley.com/go/ikeda/images/
cp -a harryfearnley.com harryfearnley.com_utf8
find ./harryfearnley.com -type f -name "*.html" -exec sed -i 's|https://harryfearnley.com/go/ikeda/images/|../images/|g' {} +
find ./harryfearnley.com_utf8 -type f -name "*.html" -exec nkf -w --overwrite {} +
find ./harryfearnley.com_utf8 -type f -name "*.html" -exec sed -i 's|https://harryfearnley.com/go/ikeda/images/|../images/|g' {} +
