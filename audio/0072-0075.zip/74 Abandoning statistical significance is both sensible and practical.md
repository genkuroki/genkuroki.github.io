* https://statmodeling.stat.columbia.edu/2019/04/16/abandoning-statistical-significance-is-both-sensible-and-practical/
* https://sites.stat.columbia.edu/gelman/research/unpublished/Amrhein_Gelman_Greenland_McShane2019.pdf
* https://peerj.com/preprints/27657/

の翻訳

* [NotebookLMで作成した音声概要](https://genkuroki.github.io/audio/74%20Abandoning%20statistical%20significance%20is%20both%20sensible%20and%20practical.m4a)

----------

# **統計的有意性を放棄することは賢明で実用的である**

Valentin Amrhein1、Andrew Gelman2、Sander Greenland3、Blakeley B. McShane4

1. バーゼル大学 環境科学・動物学部門、スイス バーゼル; v.amrhein@unibas.ch
2. コロンビア大学 政治科学・統計学部門、米国 ニューヨーク市; gelman@stat.columbia.edu
3. カリフォルニア大学ロサンゼルス校 疫学・統計学部門、米国 ロサンゼルス; lesdomes@g.ucla.edu
4. ノースウェスタン大学 ケロッグ経営大学院、米国 イリノイ州 エバンストン; b-mcshane@kellogg.northwestern.edu

## JAMA編集者様

イオアニディス博士1は、科学的推論と出版における**統計的有意性**の放棄という私たちの提案2-4に反対する文章を書いています。この提案は、アメリカ統計学会誌の最近の特集号（「ポストp<0.05ワールド」への移行に捧げられた）の**巻頭言**5で支持されたものです。私たちは、彼が「**不確実性**を受け入れ、**誇張された主張**を避け、…『**統計的有意性**』がしばしば誤解されていることを認識する」という私たちの呼びかけに同調していることを評価します。また、彼が「あらゆる結果の解釈は、単なる**有意性検定**よりもはるかに複雑である」こと、そして「臨床的、金銭的、その他の考慮事項が**統計的知見**よりも重要であることがしばしばある」という点に同意していることも歓迎します。

それにもかかわらず、私たちは、科学において**統計的有意性**に基づく「**フィルタリングプロセス**がノイズに溺れるのを避けるために有用である」という意見には同意しません。むしろ、そのようなフィルタリングは有害であると見ています。

* 第一に、**非有意な結果**を出版しないという暗黙のルールは、**過大評価された効果量**で文献を偏らせ、「**有意性**を得るための**ハッキング**」を助長します。
* 第二に、**非有意な結果**はしばしば誤ってゼロとして扱われます。
* 第三に、**有意な結果**は、それが**ノイズの多い推定値**であるにもかかわらず、しばしば誤って真実として扱われ、それによって**再現性**に対する非現実的な期待を生み出します。
* 第四に、**統計的有意性**に基づくフィルタリングは、ノイズに対する保証を提供しません。むしろ、フィルタリングの根拠となる量（**p値**）自体が極めて**ノイズ**が大きく、それを**二分する**ことによってさらに増幅されるため、ノイズを増幅させます。

私たちはまた、**統計的有意性**を放棄することが科学を「**統計的無秩序**の状態」に陥れるという意見にも同意しません。実際、**Epidemiology**誌は1990年に**統計的有意性**を禁止し、今日ではこの分野のリーダーとして認められています。

**有効な統合**には、**統計的有意性**を達成したサブセットだけでなく、すべての関連する証拠を考慮することが必要です。したがって、研究者は、すべての量に対する**推定値**と**不確実性に関する記述**を提供し、いかなる例外も正当化し、結果がどのように間違っている可能性があるかを考慮して、より多くを報告すべきであり、より少なくすべきではありません。出版基準は、研究デザイン、データ品質、および科学的コンテンツの評価に基づいて行われるべきであり、**統計的有意性**に基づいて行うべきではありません。

科学的な報告において、意思決定が必要となることはめったにありません。しかし、意思決定が必要な場合（臨床診療のように）、それらは、すべての可能な結果のコスト、利益、および**尤度**に基づいて行われるべきであり、**p値**のような統計的要約に適用される恣意的なカットオフを介して行われるべきではありません。**p値**は、この全体像のごく一部しか捉えていません。

科学における**再現性の危機**は、**信頼できない知見**の出版によって引き起こされたものではありません。**信頼できない知見**の出版は避けられないものです。「もし私たちが何をしているのか知っていたら、それは研究とは呼ばれないだろう」という言葉があるように。むしろ、**再現性の危機**は、**信頼できない知見**が信頼できるものとして提示されているために生じています。

## References

1. Ioannidis JPA. The importance of predefined rules and prespecified statistical analyses: Do not abandon significance. JAMA. Published online April 4, 2019.  doi:10.1001/jama.2019.4582
2. Amrhein V, Greenland S, McShane B. Retire statistical significance. Nature. 2019, 567, 305-307.  doi:10.1038/d41586-019-00857-9
3. McShane BB, Gal D, Gelman A, Robert C, Tackett JL. Abandon statistical significance. Am. Stat. 2019, 73:sup1, 235-245.  doi:10.1080/00031305.2018.1527253
4. Amrhein V, Trafimow D, Greenland S. Inferential statistics as descriptive statistics: There is no replication crisis if we don’t expect replication. Am. Stat. 2019, 73:sup1, 262-270. doi:10.1080/00031305.2018.1543137
5. Wasserstein RL, Schirm AL, Lazar NA. Moving to a world beyond “p<0.05”. Am Stat. 2019, 73:sup1, 1-19. doi:10.1080/00031305.2019.1583913
